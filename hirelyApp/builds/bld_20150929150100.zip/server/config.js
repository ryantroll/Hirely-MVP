/**
 * Created by labrina.loving on 9/19/2015.
 */
module.exports = function() {
    var config = {
        googleMapsAPIKey: "AIzaSyDoM7YVRZsYdeoJ3XezTX-l_eCgFz2EqfM",
        traitify: {
            host: "api-sandbox.traitify.com",
            version: "v1",
            secretKey: "bv8sstle4nsl3imb17ra0c158d"
        }
    };
    return config;
};
