This node program is an amazon lamdba function to generate image thumbs automatically
